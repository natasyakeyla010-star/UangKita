package com.uangkita.app

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private var balance = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val balanceView = findViewById<TextView>(R.id.balance)
        val status = findViewById<TextView>(R.id.status)
        val mission = findViewById<Button>(R.id.missionButton)
        val withdraw = findViewById<Button>(R.id.withdrawButton)

        fun refresh() {
            balanceView.text = "Saldo\nRp${"%,d".format(balance).replace(',', '.')}"
        }

        mission.setOnClickListener {
            balance += 1000
            refresh()
            status.text = "Misi selesai. Rp1.000 ditambahkan ke saldo demo."
        }

        withdraw.setOnClickListener {
            status.text = if (balance >= 10000) {
                "Permintaan pencairan demo dibuat. Integrasi payout nyata perlu backend."
            } else {
                "Minimal pencairan demo Rp10.000."
            }
        }

        refresh()
    }
}
