# UangKita

Project Android siap dibangun melalui GitHub Actions.

## Cara mendapatkan APK
1. Buat repository GitHub baru, misalnya `UangKita`.
2. Upload seluruh isi folder ini.
3. Buka tab **Actions**.
4. Pilih **Build UangKita APK**.
5. Tekan **Run workflow**.
6. Setelah selesai, buka hasil run dan download artifact **UangKita-debug-apk**.

Catatan: versi ini adalah APK demo yang dapat dibangun. Pencairan uang nyata belum diaktifkan; itu memerlukan backend, autentikasi, validasi transaksi, dan penyedia payout.
